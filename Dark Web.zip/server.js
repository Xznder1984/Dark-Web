const express = require("express");
const path = require("path");
const app = express();
const port = process.env.PORT || 3000;

// Serve files from /public folder
app.use(express.static(path.join(__dirname, "public")));

// Optional: fallback to index.html for unknown routes (good for single page apps)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => {
  console.log(`🚀 Server running on port ${port}`);
});
