let items = [];

const container = document.getElementById("items-container");
const modal = document.getElementById("checkout-modal");
const summary = document.getElementById("checkout-summary");

fetch("items.json")
  .then(res => res.json())
  .then(data => {
    items = data;
    renderItems();
  });

function renderItems() {
  items.forEach((item, index) => {
    const div = document.createElement("div");
    div.className = "item";
    div.innerHTML = `
      <img src="${item.img}" alt="${item.name}" />
      <h3>${item.name}</h3>
      <p>${item.price}</p>
      <button onclick="checkout(${index})">Buy Now</button>
    `;
    container.appendChild(div);
  });
}

function checkout(index) {
  const item = items[index];
  summary.innerHTML = `You are buying <strong>${item.name}</strong> for <strong>${item.price}</strong>.`;
  modal.classList.remove("hidden");
}

function closeCheckout() {
  modal.classList.add("hidden");
}

function submitCheckout(event) {
  event.preventDefault();
  alert("Order submitted! (Not really)");
  closeCheckout();
}
